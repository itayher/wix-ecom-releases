#!/usr/bin/env node
/**
 * Wix Store Optimizer - MCP Server
 * Handles API calls outside the Cowork sandbox
 */

const { Server } = require('@modelcontextprotocol/sdk/server/index.js');
const { StdioServerTransport } = require('@modelcontextprotocol/sdk/server/stdio.js');
const { CallToolRequestSchema, ListToolsRequestSchema } = require('@modelcontextprotocol/sdk/types.js');

const WIX_APP_ID = 'df7c18eb-009b-4868-9891-15e19dddbe67';
const WIX_API_BASE = 'https://www.wixapis.com';
const ACCESS_TOKEN = process.env.WIX_ACCESS_TOKEN || '';

const { getSelectedSite, saveSelectedSite } = require('./lib/site-storage.js');

const server = new Server({ name: 'wix-store-optimizer', version: '1.0.0' }, { capabilities: { tools: {} } });

server.setRequestHandler(ListToolsRequestSchema, async () => ({
  tools: [
    { name: 'wix_list_sites', description: 'List all Wix sites', inputSchema: { type: 'object', properties: {} } },
    { name: 'wix_select_site', description: 'Select site by number', inputSchema: { type: 'object', properties: { site_number: { type: 'number' } }, required: ['site_number'] } },
    { name: 'wix_api_call', description: 'Make any Wix API call', inputSchema: { type: 'object', properties: { method: { type: 'string' }, endpoint: { type: 'string' }, body: { type: 'object' } }, required: ['method', 'endpoint'] } }
  ]
}));

server.setRequestHandler(CallToolRequestSchema, async (request) => {
  const { name, arguments: args } = request.params;

  try {
    if (name === 'wix_list_sites') {
      const res = await fetch(`${WIX_API_BASE}/v1/sites`, {
        headers: { 'Authorization': ACCESS_TOKEN }
      });
      const data = await res.json();
      return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
    }

    if (name === 'wix_select_site') {
      // Selection logic handled by plugin
      return { content: [{ type: 'text', text: JSON.stringify({ success: true }) }] };
    }

    if (name === 'wix_api_call') {
      const site = getSelectedSite();
      const url = `${WIX_API_BASE}${args.endpoint}`;
      const options = {
        method: args.method,
        headers: {
          'Authorization': ACCESS_TOKEN,
          'Content-Type': 'application/json',
          'wix-site-id': site?.siteId || ''
        }
      };
      if (args.body) options.body = JSON.stringify(args.body);

      const res = await fetch(url, options);
      const data = await res.json();
      return { content: [{ type: 'text', text: JSON.stringify(data, null, 2) }] };
    }
  } catch (error) {
    return { content: [{ type: 'text', text: `Error: ${error.message}` }], isError: true };
  }
});

async function main() {
  const transport = new StdioServerTransport();
  await server.connect(transport);
  console.error('Wix Store Optimizer MCP Server ready');
}

main();
