# Create Campaign - Guided Campaign Creation

Interactive workflow to create targeted discount campaigns: clearance sales, AOV boosters, product spotlights, and more.

## Command Pattern

```
Create a campaign
Create a clearance sale
Create a discount for slow-moving products
Boost average order value
Create a product spotlight promotion
```

## Workflow

### Step 1: Validate Configuration

```bash
node -e "
const { getActiveSiteId, getActiveSiteName } = require('./wix-store-optimizer/lib/site-storage');
const { validateConfig } = require('./lib/config-validator');

const validation = validateConfig();
if (!validation.valid) {
  console.error(validation.message);
  process.exit(1);
}

const siteId = getActiveSiteId();
if (!siteId) {
  console.error('❌ No site selected.');
  process.exit(1);
}

console.error(\`✓ Creating campaign for: \${getActiveSiteName()}\`);
"
```

### Step 2: Select Campaign Type

Present campaign options based on **discount-strategy** skill patterns:

```
Available Campaign Types:

1. 🏷️  Clearance Sale (20-40% off slow movers)
2. 💰 AOV Booster (Spend $X, save $Y)
3. ⭐ Product Spotlight (Discount on specific products)
4. 🚚 Free Shipping Threshold (Free shipping over $X)
5. 🎁 Buy X Get Y (BOGO deals)
```

### Step 3: Campaign Type 1 - Clearance Sale

For slow-moving inventory identified in inventory audit:

```bash
SITE_ID=$(node -e "const { getActiveSiteId } = require('./wix-store-optimizer/lib/site-storage'); console.log(getActiveSiteId());")
API_KEY="${WIX_API_KEY}"

echo "🏷️  CLEARANCE SALE CAMPAIGN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Get slow-moving products (products with inventory but no recent sales)
thirty_days_ago=$(date -u -v-30d +"%Y-%m-%dT%H:%M:%S.000Z" 2>/dev/null || date -u -d "30 days ago" +"%Y-%m-%dT%H:%M:%S.000Z")

products=$(curl -s -X POST "https://www.wixapis.com/stores/v1/products/query" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d '{"query": {"paging": {"limit": 100}}}')

orders=$(curl -s -X POST "https://www.wixapis.com/stores/v2/orders/query" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d "{\"query\": {\"filter\": \"{\\\"dateCreated\\\": {\\\"\\$gte\\\": \\\"$thirty_days_ago\\\"}, \\\"paymentStatus\\\": \\\"PAID\\\"}\", \"paging\": {\"limit\": 1000}}}")

sold_product_ids=$(echo "$orders" | jq -r '.orders[] | .lineItems[] | .productId' | sort -u)

slow_movers=$(echo "$products" | jq --argjson sold_ids "$(echo "$sold_product_ids" | jq -R . | jq -s .)" -r '
[.products[]
| select(.stock.trackInventory == true and (.stock.quantity // 0) > 0)
| select(.id as $id | ($sold_ids | index($id)) == null)
| {id, name, quantity: .stock.quantity, price: .price}]
')

slow_mover_count=$(echo "$slow_movers" | jq 'length')

echo "Found $slow_mover_count slow-moving products"
echo ""
echo "Slow Movers:"
echo "$slow_movers" | jq -r '.[] | "   • \(.name): \(.quantity) units @ $\(.price)"'
echo ""

# Prompt for discount percentage
DISCOUNT_PERCENT=30

echo "Recommended discount: 30% off"
echo "Creating coupon: CLEARANCE30"
echo ""

# Create coupon
curl -s -X POST "https://www.wixapis.com/stores/v2/coupons" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d "{
  \"coupon\": {
    \"name\": \"Clearance Sale - ${DISCOUNT_PERCENT}% Off\",
    \"code\": \"CLEARANCE${DISCOUNT_PERCENT}\",
    \"startTime\": \"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")\",
    \"endTime\": \"$(date -u -v+30d +"%Y-%m-%dT%H:%M:%S.000Z" 2>/dev/null || date -u -d "30 days" +"%Y-%m-%dT%H:%M:%S.000Z")\",
    \"specification\": {
      \"percentOffAmount\": ${DISCOUNT_PERCENT},
      \"scope\": {
        \"namespace\": \"stores\"
      }
    },
    \"limitedToOneItem\": false
  }
}" | jq '{
  id: .coupon.id,
  code: .coupon.code,
  discount: "\(.coupon.specification.percentOffAmount)%",
  validUntil: .coupon.endTime,
  message: "✅ Clearance campaign created!"
}'

echo ""
echo "📧 NEXT STEPS:"
echo "1. Add CLEARANCE${DISCOUNT_PERCENT} code to your homepage"
echo "2. Send email to customers announcing the sale"
echo "3. Create collection 'Clearance Items' with these products"
```

### Step 4: Campaign Type 2 - AOV Booster

Spend threshold discounts to increase average order value:

```bash
echo "💰 AOV BOOSTER CAMPAIGN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Calculate current AOV
orders=$(curl -s -X POST "https://www.wixapis.com/stores/v2/orders/query" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d "{\"query\": {\"filter\": \"{\\\"dateCreated\\\": {\\\"\\$gte\\\": \\\"$thirty_days_ago\\\"}, \\\"paymentStatus\\\": \\\"PAID\\\"}\", \"paging\": {\"limit\": 1000}}}")

current_aov=$(echo "$orders" | jq '[.orders[] | .priceSummary.total | tonumber] | add / length')

echo "Current AOV: \$${current_aov}"
echo ""

# Recommend threshold at 1.5x AOV
threshold=$(echo "scale=0; $current_aov * 1.5 / 1" | bc)
discount_amount=10

echo "Recommended: Spend \$${threshold}, save \$${discount_amount}"
echo ""

# Create coupon
curl -s -X POST "https://www.wixapis.com/stores/v2/coupons" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d "{
  \"coupon\": {
    \"name\": \"Spend \$${threshold}, Save \$${discount_amount}\",
    \"code\": \"SAVE${discount_amount}\",
    \"startTime\": \"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")\",
    \"specification\": {
      \"moneyOffAmount\": \"${discount_amount}.00\",
      \"minimumSubtotal\": \"${threshold}.00\",
      \"scope\": {
        \"namespace\": \"stores\"
      }
    }
  }
}" | jq '{
  code: .coupon.code,
  discount: "$\(.coupon.specification.moneyOffAmount)",
  minSpend: "$\(.coupon.specification.minimumSubtotal)",
  message: "✅ AOV booster created!"
}'

echo ""
echo "📊 EXPECTED IMPACT:"
echo "• Encourages customers to add \$$(echo "$threshold - $current_aov" | bc) more"
echo "• Increases cart size by ~$(echo "scale=0; ($threshold - $current_aov) / $current_aov * 100" | bc)%"
```

### Step 5: Campaign Type 3 - Product Spotlight

Promote specific products with targeted discounts:

```bash
echo "⭐ PRODUCT SPOTLIGHT CAMPAIGN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Get top selling products from last 30 days
top_products=$(echo "$orders" | jq -r '
.orders[]
| .lineItems[]
| {name, productId, quantity, revenue: ((.price | tonumber) * .quantity)}
' | jq -s 'group_by(.productId) | map({
  name: .[0].name,
  productId: .[0].productId,
  totalSold: (map(.quantity) | add),
  totalRevenue: (map(.revenue) | add)
}) | sort_by(-.totalRevenue) | .[0:5]')

echo "🔥 TOP 5 PRODUCTS (Last 30 Days):"
echo "$top_products" | jq -r '.[] | "   \(.totalSold). \(.name) - $\(.totalRevenue | floor) revenue"'
echo ""

# Create percentage-off coupon for featured products
SPOTLIGHT_DISCOUNT=15

curl -s -X POST "https://www.wixapis.com/stores/v2/coupons" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d "{
  \"coupon\": {
    \"name\": \"Spotlight - ${SPOTLIGHT_DISCOUNT}% Off Best Sellers\",
    \"code\": \"SPOTLIGHT${SPOTLIGHT_DISCOUNT}\",
    \"startTime\": \"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")\",
    \"specification\": {
      \"percentOffAmount\": ${SPOTLIGHT_DISCOUNT},
      \"scope\": {
        \"namespace\": \"stores\"
      }
    }
  }
}" | jq '{
  code: .coupon.code,
  discount: "\(.coupon.specification.percentOffAmount)%",
  message: "✅ Product spotlight created!"
}'

echo ""
echo "💡 PROMOTION IDEAS:"
echo "• Feature these products on homepage"
echo "• Send targeted email with SPOTLIGHT${SPOTLIGHT_DISCOUNT} code"
echo "• Create Instagram post highlighting the deal"
```

### Step 6: Campaign Type 4 - Free Shipping Threshold

```bash
echo "🚚 FREE SHIPPING CAMPAIGN"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""

# Recommend threshold at 1.2x AOV
free_ship_threshold=$(echo "scale=0; $current_aov * 1.2 / 1" | bc)

echo "Current AOV: \$${current_aov}"
echo "Recommended threshold: \$${free_ship_threshold}"
echo ""

curl -s -X POST "https://www.wixapis.com/stores/v2/coupons" \
  -H "Authorization: ${API_KEY}" \
  -H "wix-site-id: ${SITE_ID}" \
  -H "Content-Type: application/json" \
  -d "{
  \"coupon\": {
    \"name\": \"Free Shipping Over \$${free_ship_threshold}\",
    \"code\": \"FREESHIP${free_ship_threshold}\",
    \"startTime\": \"$(date -u +"%Y-%m-%dT%H:%M:%S.000Z")\",
    \"specification\": {
      \"freeShipping\": true,
      \"minimumSubtotal\": \"${free_ship_threshold}.00\",
      \"scope\": {
        \"namespace\": \"stores\"
      }
    }
  }
}" | jq '{
  code: .coupon.code,
  minSpend: "$\(.coupon.specification.minimumSubtotal)",
  message: "✅ Free shipping campaign created!"
}'
```

## Output Format

```
✓ Creating campaign for: My Store

Available Campaign Types:

1. 🏷️  Clearance Sale (20-40% off slow movers)
2. 💰 AOV Booster (Spend $X, save $Y)
3. ⭐ Product Spotlight (Discount on specific products)
4. 🚚 Free Shipping Threshold

Selected: Clearance Sale

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Found 12 slow-moving products

Creating coupon: CLEARANCE30

✅ Clearance campaign created!

Campaign Details:
• Code: CLEARANCE30
• Discount: 30%
• Valid Until: 2026-03-23
• Products: 12 items

📧 NEXT STEPS:
1. Add CLEARANCE30 code to homepage
2. Send email announcing the sale
3. Create 'Clearance' collection
```

## Skills Referenced

- **discount-strategy**: Coupon creation patterns, margin calculations
- **inventory-management**: Slow-mover detection
- **order-analytics**: AOV calculation, top product analysis

## Example Use Cases

1. **Clear Dead Stock**: "Create a clearance campaign for slow-moving products"
2. **Increase Cart Size**: "Create an AOV booster campaign"
3. **Promote Bestsellers**: "Create a spotlight for top products"
4. **Shipping Promo**: "Create free shipping over a threshold"
5. **Seasonal Sale**: "Create a campaign for spring clearance"

## Related Commands

- `/wix:inventory-audit` - Identify products for clearance
- `/wix:discount-manager` - View and manage all coupons
- `/wix:revenue-report` - Measure campaign impact
