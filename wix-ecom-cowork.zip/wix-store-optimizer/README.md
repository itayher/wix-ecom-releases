# 🛍️ Wix Store Optimizer - Claude Desktop Plugin

Complete Wix eCommerce store management through natural conversation with Claude!

## ⚡ Quick Install

1. **Download** this plugin from Google Drive
2. **Extract** the zip file
3. **Upload to Claude:** Settings → Browse Plugins → Upload Local Plugin
4. **Configure:** Add your Wix API key and Site ID in plugin settings
5. **Restart** Claude Desktop
6. **Start using:** "Show me my Wix sites"

## 🎯 What You Can Do

### Store Management
- Analyze entire store health with scored report
- Manage products (search, create, update, bulk operations)
- Audit inventory (ABC analysis, slow-movers, clearance items)
- Optimize product listings (SEO, descriptions, images)

### Revenue Optimization
- Create discount campaigns (clearance, AOV boost, spotlight)
- Manage coupon codes and automatic discounts
- Revenue reporting with trends and forecasts
- Customer segmentation and insights

### Operations
- View and manage orders
- Monitor inventory levels
- Configure shipping and tax rules
- Customer analytics and history

## 📋 Available Commands

| Command | What It Does |
|---------|-------------|
| `/wix:analyze-store` | Full health analysis with scored report |
| `/wix:products` | Manage products (search, create, update) |
| `/wix:inventory-audit` | Find slow-movers and clearance opportunities |
| `/wix:create-campaign` | Guided discount campaign creation |
| `/wix:discount-manager` | Manage all coupons and discounts |
| `/wix:optimize-products` | Fix product listing issues |
| `/wix:orders` | View and analyze orders |
| `/wix:revenue-report` | Revenue analysis and trends |
| `/wix:customers` | Customer segmentation and insights |
| `/wix:shipping-tax` | Manage shipping and tax settings |

## ⚙️ Configuration (Through Claude UI)

After uploading the plugin, configure these in **Claude Settings → Plugins → wix-store-optimizer**:

### Required Settings:

```
WIX_API_KEY = (Your Wix API key from manage.wix.com/account/api-keys)
WIX_SITE_1_ID = (Your Site ID from dashboard URL)
WIX_SITE_1_NAME = (Store name, e.g., "Joe's Surf Shop")
```

### Optional (Multiple Stores):

```
WIX_SITE_2_ID = (Another site ID)
WIX_SITE_2_NAME = (Another store name)
WIX_SITE_3_ID = (Third site ID)
WIX_SITE_3_NAME = (Third store name)
```

## 🔑 Getting Your API Key

1. Go to: **https://manage.wix.com/account/api-keys**
2. Click **"Create API Key"**
3. Name: `Claude Desktop`
4. Select permissions:
   - ✅ Read Products, Write Products
   - ✅ Read Orders, Write Orders
   - ✅ Read Inventory, Write Inventory
   - ✅ Read Coupons, Write Coupons
5. Copy the generated key (starts with `IST.`)

## 🆔 Finding Your Site ID

1. Go to your Wix dashboard
2. Look at the URL:
   ```
   https://manage.wix.com/dashboard/YOUR-SITE-ID-HERE/home
                                    ^^^^^^^^^^^^^^^^^^^^
                                    This is your Site ID
   ```
3. Copy that GUID (example: `331d0c05-2ab0-4edb-91a6-4078c7e500b9`)

## 🚀 First Use

After configuration and restart:

```
"Show me my Wix sites"
→ Claude lists all configured sites

"Connect to site 1"
→ Claude connects to that store

"Analyze my store"
→ Claude runs full health analysis

"Show me my products"
→ Claude displays your catalog
```

## 💡 Example Conversations

**Inventory Management:**
```
You: "Check my inventory"
Claude: [Site: Joe's Surf Shop] Found 15 low stock items...

You: "Show me slow-moving products"
Claude: ABC Analysis shows 23 C-tier products...

You: "Create a clearance campaign for those"
Claude: I'll create a 30% off campaign for 23 products...
```

**Revenue Optimization:**
```
You: "I need help with revenue"
Claude: Let me analyze your store... [runs full audit]

You: "Create an AOV booster campaign"
Claude: Your current AOV is $65. I'll create a "Spend $75 get 15% off" campaign...
```

## 🎓 What's Included

### 9 Expert Skills
- Wix API patterns
- Product & inventory management
- Discount strategy & margin math
- Order & customer analytics
- Catalog optimization
- Shipping & tax configuration
- Complete store analysis

### 10 Powerful Commands
- Store health analysis
- Product management
- Inventory audits
- Campaign creation
- Revenue reports
- And more...

### 2 Specialized Agents
- **Catalog Agent** - Bulk operations (batches of 20)
- **Pricing Agent** - Margin-safe discount creation

## 🔒 Security & Privacy

- ✅ API key stored securely in Claude settings
- ✅ All data stays between you, Claude, and Wix
- ✅ App ID hard-coded for security: `df7c18eb-009b-4868-9891-15e19dddbe67`
- ✅ No third-party services
- ✅ Open source - review the code yourself

## 🛠️ Troubleshooting

### "Not configured" errors
- Check Settings → Plugins → wix-store-optimizer
- Verify `WIX_API_KEY` is set
- Verify at least one site is configured

### "No site selected"
Say: `"Show me my Wix sites"` then `"Connect to site 1"`

### API key errors
- Make sure API key has all required permissions
- Verify you're the site owner (not co-owner)

## 📖 For More Help

See the `/skills/README.md` file for detailed API documentation and troubleshooting.

---

**Version:** 1.0.0
**Last Updated:** 2026-02-21
**Total Lines:** 9,118 (skills + commands)
**Phase:** 1 - Complete

**Made with ❤️ for Wix store owners**
